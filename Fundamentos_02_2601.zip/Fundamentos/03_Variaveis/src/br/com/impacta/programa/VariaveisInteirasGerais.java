package br.com.impacta.programa;

public class VariaveisInteirasGerais {
	public static void main(String[] args) {
		int b_decimal = 100;
		int b_octal = 0107;
		int b_hexadecimal = 0xacff00;
		int b_binaria = 0b100;
		
		System.out.println("Decimal: " + b_decimal);
		System.out.println("Octal: " + b_octal);
		System.out.println("Hexadecimal: " + b_hexadecimal);
		System.out.println("Binaria: " + b_binaria);
	}
}
