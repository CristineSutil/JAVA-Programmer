package br.com.impacta.programa;

import javax.swing.JOptionPane;

public class Conceito {
	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Exemplo de pacotes");
	}
}
