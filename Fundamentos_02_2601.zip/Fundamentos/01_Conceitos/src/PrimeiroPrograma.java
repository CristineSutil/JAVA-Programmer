
public class PrimeiroPrograma {
	public static void main(String args[]) {
		System.out.println("Exemplo de programa Java");
		System.out.println("Codigo Fonte e Bytecode");
		System.out.println();
		System.out.println("JVM, JDK e JRE");
	}
}
