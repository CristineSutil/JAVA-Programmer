package br.com.impacta.programa;

public class Conceitos {
public static void main(String[] args) {
	
//	System.out.println("Curso Java"); nunca fazer isso
//	System.out.println("Curso Java");
//	System.out.println("Curso Java");
//	System.out.println("Curso Java");
//	System.out.println("Curso Java");
	
	for(int i = 0; i < 5 ; i++) {
		System.out.println("Curso Java");
	}
	System.out.println("----Fim do programa ----");
}
}
