package br.com.impacta.programa;

public class ExemploWhile {
	public static void main(String[] args) {
		
		int contador = 20;
		while(contador > 10) {
			System.out.println("Posi��o: " + contador --);
			
		}
			System.out.println("----Finalizado-----");
}
}
