package br.com.impacta.utilitarios;

public class Calculos {
	public static double calcularSoma(double a, double b) {
		
		return a + b;
}
}

