package br.com.impacta.enumeracoes;

public enum Sexo {
	MASCULINO, FEMININO, OUTROS 
}
