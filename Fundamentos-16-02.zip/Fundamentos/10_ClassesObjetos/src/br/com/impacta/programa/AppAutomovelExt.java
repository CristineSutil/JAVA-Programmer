package br.com.impacta.programa;

import br.com.impacta.classes.Automovel;

public class AppAutomovelExt {
public static void main(String[] args) {
	
	//fiat, palio, 2016
	
	Automovel auto1 = new Automovel();
	auto1.marca = "Fiat";
	auto1.modelo = "Palio";
	auto1.ano = 2016;
	
}
}
