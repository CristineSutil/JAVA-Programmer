package br.com.impacta.classes.exercicios;

public class Imovel {
	public String desc;
	public double area;
	public String end;

}
