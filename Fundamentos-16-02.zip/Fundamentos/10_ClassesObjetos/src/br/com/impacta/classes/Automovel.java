package br.com.impacta.classes;

public class Automovel {
	public String marca;
	public String modelo;
	public int ano;
	
		
}
