package br.com.impacta.programa;

public class OperadorMultiplicacao {
	public static void main(String[] args) {
		int a = 10, b = 5, c = 2;
		
		int resposta = a + b * c;
		System.out.println(resposta);
	}
}
